package com.arduino.roadsage;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.speech.RecognizerIntent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.EditText;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    Button btn1, btn2, btn3, btn4, stop;
    public static final String TAG = "LOGTAG";
    ImageButton imgbtn;
    ImageView img;
    TextView txt;
    final Handler handler = new Handler();

    public static UUID UART_UUID = UUID.fromString("6E400001-B5A3-F393-E0A9-E50E24DCCA9E");
    public static UUID TX_UUID = UUID.fromString("6E400002-B5A3-F393-E0A9-E50E24DCCA9E");
    public static UUID RX_UUID = UUID.fromString("6E400003-B5A3-F393-E0A9-E50E24DCCA9E");
    // UUID for the BTLE client characteristic which is necessary for notifications.
    public static UUID CLIENT_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    // BTLE state
    private BluetoothAdapter adapter;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic tx;
    private BluetoothGattCharacteristic rx;

    final int REQ_CODE_SPEECH_INPUT = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        btn3 = (Button) findViewById(R.id.btn3);
        btn4 = (Button) findViewById(R.id.btn4);
        imgbtn = (ImageButton) findViewById(R.id.center_logo);
        img = (ImageView) findViewById(R.id.image1);
        txt = (TextView) findViewById(R.id.textView);

        // Retrieve Saved Values
        Get();

        RunAnimation();

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        imgbtn.setOnClickListener(new myOnClickListener());
        btn1.setOnClickListener(new myOnClickListener());
        btn1.setOnLongClickListener(new myLongOnClickListener());
        btn2.setOnClickListener(new myOnClickListener());
        btn2.setOnLongClickListener(new myLongOnClickListener());
        btn3.setOnClickListener(new myOnClickListener());
        btn3.setOnLongClickListener(new myLongOnClickListener());
        btn4.setOnClickListener(new myOnClickListener());
        btn4.setOnLongClickListener(new myLongOnClickListener());

        adapter = BluetoothAdapter.getDefaultAdapter();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.item1:
                writeLine("Connect button pressed");
                adapter.startLeScan(scanCallback);
                return true;
            case R.id.item2:
                writeLine("Disconnect button pressed");
                gatt.disconnect();
                return true;
            case R.id.item3:
                writeLine("Clearing Screen");
                Clear();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void RunAnimation(){
        final Animation animation = new TranslateAnimation(0,-685,0,0);
        animation.setDuration(1500);
        animation.setFillAfter(true);
        img.startAnimation(animation);
    }

    @Override
    protected void onResume() {
        super.onResume();
        writeLine("onResume Called");
        writeLine("Scanning for devices...");
        adapter.startLeScan(scanCallback);
        // Scan for all BTLE devices.
        // The first one with the UART service will be chosen--see the code in the scanCallback.
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
            adapter.stopLeScan(scanCallback);
            }
        }, 1500);
    }

    // OnStop, called right before the activity loses foreground focus.  Close the BTLE connection.
    @Override
    protected void onStop() {
        super.onStop();
        if (gatt != null) {
            // For better reliability be careful to disconnect and close the connection.
            gatt.disconnect();
            gatt.close();
            gatt = null;
            tx = null;
            rx = null;
        }
        Save();
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    private final class myOnClickListener implements View.OnClickListener {

        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case (R.id.center_logo):
                    Log.i(TAG, "center button clicked");
                    promptSpeechInput();
                    break;
                case (R.id.btn1):
                    Log.i(TAG, "Button 1 clicked");
                    sendClick(btn1);
                    break;
                case (R.id.btn2):
                    Log.i(TAG, "Button 2 clicked");
                    sendClick(btn2);
                    break;
                case (R.id.btn3):
                    Log.i(TAG, "Button 3 clicked");
                    sendClick(btn3);
                    break;
                case (R.id.btn4):
                    Log.i(TAG, "Button 4 clicked");
                    sendClick(btn4);
                    break;
            }
        }
    }

    private final class myLongOnClickListener implements View.OnLongClickListener {

        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        @Override
        public boolean onLongClick(View view) {
            switch (view.getId()) {
                case (R.id.center_logo):
                    adapter.stopLeScan(scanCallback);
                case (R.id.btn1):
                    Log.i(TAG, "Button 1 Long clicked");
                    setButtonText(btn1);
                    v.vibrate(1000);
                    return true;
                case (R.id.btn2):
                    Log.i(TAG, "Button 2 Long clicked");
                    v.vibrate(1000);
                    setButtonText(btn2);
                    return true;
                case (R.id.btn3):
                    Log.i(TAG, "Button 3 Long clicked");
                    v.vibrate(1000);
                    setButtonText(btn3);
                    return true;
                case (R.id.btn4):
                    Log.i(TAG, "Button 4 Long clicked");
                    v.vibrate(1000);
                    setButtonText(btn4);
                    return true;
                default:
                    return true;
            }
        }
    }

    private void setButtonText(final Button btn) {
        LayoutInflater li = LayoutInflater.from(this);
        View dialogView = li.inflate(R.layout.activity_edit_text, null);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

        alertDialogBuilder.setView(dialogView);

        final EditText userInput = (EditText) dialogView.findViewById(R.id.editTextDialogUserInput);

        alertDialogBuilder.setCancelable(true).setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Log.i(TAG, "User said: " + userInput.getText());
                btn.setText(userInput.getText());
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();

        alertDialog.show();
    }

    private void writeLine(final String text) {
        Log.i(TAG, text);
    }

    private List<UUID> parseUUIDs(final byte[] advertisedData) {
        List<UUID> uuids = new ArrayList<UUID>();

        int offset = 0;
        while (offset < (advertisedData.length - 2)) {
            int len = advertisedData[offset++];
            if (len == 0)
                break;

            int type = advertisedData[offset++];
            switch (type) {
                case 0x02: // Partial list of 16-bit UUIDs
                case 0x03: // Complete list of 16-bit UUIDs
                    while (len > 1) {
                        int uuid16 = advertisedData[offset++];
                        uuid16 += (advertisedData[offset++] << 8);
                        len -= 2;
                        uuids.add(UUID.fromString(String.format("%08x-0000-1000-8000-00805f9b34fb", uuid16)));
                    }
                    break;
                case 0x06:// Partial list of 128-bit UUIDs
                case 0x07:// Complete list of 128-bit UUIDs
                    // Loop through the advertised 128-bit UUID's.
                    while (len >= 16) {
                        try {
                            // Wrap the advertised bits and order them.
                            ByteBuffer buffer = ByteBuffer.wrap(advertisedData, offset++, 16).order(ByteOrder.LITTLE_ENDIAN);
                            long mostSignificantBit = buffer.getLong();
                            long leastSignificantBit = buffer.getLong();
                            uuids.add(new UUID(leastSignificantBit,
                                    mostSignificantBit));
                        } catch (IndexOutOfBoundsException e) {
                            // Defensive programming.
                            //Log.e(LOG_TAG, e.toString());
                            continue;
                        } finally {
                            // Move the offset to read the next uuid.
                            offset += 15;
                            len -= 16;
                        }
                    }
                    break;
                default:
                    offset += (len - 1);
                    break;
            }
        }
        return uuids;
    }
    private BluetoothAdapter.LeScanCallback scanCallback = new BluetoothAdapter.LeScanCallback() {
        // Called when a device is found.
        @Override
        public void onLeScan(BluetoothDevice bluetoothDevice, int i, byte[] bytes) {
            writeLine("Found device: " + bluetoothDevice.getAddress());
            // Check if the device has the UART service.
            if (parseUUIDs(bytes).contains(UART_UUID)) {
                // Found a device, stop the scan.
                adapter.stopLeScan(scanCallback);
                writeLine("Found UART service!");
                // Connect to the device.
                // Control flow will now go to the callback functions when BTLE events occur.
                gatt = bluetoothDevice.connectGatt(getApplicationContext(), false, callback);
            }
        }
    };
    // Main BTLE device callback where much of the logic occurs.
    private BluetoothGattCallback callback = new BluetoothGattCallback() {
        // Called whenever the device connection state changes, i.e. from disconnected to connected.
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            super.onConnectionStateChange(gatt, status, newState);
            if (newState == BluetoothGatt.STATE_CONNECTED) {
                writeLine("Connected!");
                // Discover services.
                if (!gatt.discoverServices()) {
                    writeLine("Failed to start discovering services!");
                }
            }
            else if (newState == BluetoothGatt.STATE_DISCONNECTED) {
                writeLine("Disconnected!");
            }
            else {
                writeLine("Connection state changed.  New state: " + newState);
            }
        }

        // Called when services have been discovered on the remote device.
        // It seems to be necessary to wait for this discovery to occur before
        // manipulating any services or characteristics.
        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            super.onServicesDiscovered(gatt, status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                writeLine("Service discovery completed!");
            }
            else {
                writeLine("Service discovery failed with status: " + status);
            }
            // Save reference to each characteristic.
            tx = gatt.getService(UART_UUID).getCharacteristic(TX_UUID);
            rx = gatt.getService(UART_UUID).getCharacteristic(RX_UUID);
            // Setup notifications on RX characteristic changes (i.e. data received).
            // First call setCharacteristicNotification to enable notification.
            if (!gatt.setCharacteristicNotification(rx, true)) {
                writeLine("Couldn't set notifications for RX characteristic!");
            }
            // Next update the RX characteristic's client descriptor to enable notifications.
            if (rx.getDescriptor(CLIENT_UUID) != null) {
                BluetoothGattDescriptor desc = rx.getDescriptor(CLIENT_UUID);
                desc.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                if (!gatt.writeDescriptor(desc)) {
                    writeLine("Couldn't write RX client descriptor value!");
                }
            }
            else {
                writeLine("Couldn't get RX client descriptor!");
            }
        }

        // Called when a remote characteristic changes (like the RX characteristic).
        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            super.onCharacteristicChanged(gatt, characteristic);
            writeLine("Received: " + characteristic.getStringValue(0));
        }
    };


    public void sendClick(Button btn) {
        String message = btn.getText().toString();
        if (tx == null || message == null || message.isEmpty()) {
            // Do nothing if there is no device or message to send.
            return;
        }
        // Update TX characteristic value.  Note the setValue overload that takes a byte array must be used.
        tx.setValue(message.getBytes(Charset.forName("UTF-8")));
        if (gatt.writeCharacteristic(tx)) {
            txt.setText(message);
            //ClearScreen();
            RunAnimation();
            writeLine("Sent: " + message);
        }
        else {
            writeLine("Couldn't write TX characteristic!");
        }
    }

    public void sendClick(String text) {
        String message = text;
        if (tx == null || message == null || message.isEmpty()) {
            // Do nothing if there is no device or message to send.
            return;
        }
        // Update TX characteristic value.  Note the setValue overload that takes a byte array must be used.
        tx.setValue(message.getBytes(Charset.forName("UTF-8")));
        if (gatt.writeCharacteristic(tx)) {
            //ClearScreen();
            RunAnimation();
            writeLine("Sent: " + message);
            txt.setText(message);
        }
        else {
            writeLine("Couldn't write TX characteristic!");
        }
    }

    private void promptSpeechInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
                getString(R.string.speech_prompt));
        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getApplicationContext(),
                    getString(R.string.speech_not_supported),
                    Toast.LENGTH_SHORT).show();
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQ_CODE_SPEECH_INPUT: {
                if (resultCode == RESULT_OK && null != data) {
                    writeLine("onActivityResult Called");
                    ArrayList<String> result = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    String text = result.get(0);
                    sendClick(text);
                }
                break;
            }
        }
    }

    public void Save() {
        SharedPreferences sharedPref = getSharedPreferences("Button Text", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("Button 1", btn1.getText().toString());
        editor.putString("Button 2", btn2.getText().toString());
        editor.putString("Button 3", btn3.getText().toString());
        editor.putString("Button 4", btn4.getText().toString());
        editor.commit();
    }

    public void Get() {

        SharedPreferences sharedPref = getSharedPreferences("Button Text", Context.MODE_PRIVATE);
        btn1.setText(sharedPref.getString("Button 1", "I'm Sorry!"));
        btn2.setText(sharedPref.getString("Button 2", "Parking"));
        btn3.setText(sharedPref.getString("Button 3", "Go Around Me"));
        btn4.setText(sharedPref.getString("Button 4", "Thank You!"));
    }

    private void ClearScreen() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                tx.setValue((" ").getBytes(Charset.forName("UTF-8")));
                if (gatt.writeCharacteristic(tx)) {
                    writeLine("Clearing Screen");
                }
            }
        }, 7550);
    }

    private void Clear() {
        tx.setValue((" ").getBytes(Charset.forName("UTF-8")));
        if (gatt.writeCharacteristic(tx)) {
            writeLine("Clearing Screen");
        }
    }
}